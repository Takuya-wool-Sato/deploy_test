<?php get_header(); ?>
<div class="container top-page">
  <section class="section-group main">
  </section>
  <section class="section-group">
    <div class="section-group__inner">
    </div>
  </section>
</div>
<?php get_footer(); ?>