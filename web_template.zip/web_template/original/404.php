<?php get_header(); ?>
<div class="container page-second page-404">
  <section class="section-group">
    <div class="section-group__inner">
    </div>
  </section>
</div>
<?php get_footer(); ?>