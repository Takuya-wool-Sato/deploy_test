<?php get_header(); ?>
<div class="container page-second page-individuals">
  <div class="second-header">
    <img src="<?php bloginfo('template_directory'); ?>/images/second-header_logo.svg" alt="top_logo" class="top-logo pc" width="">
  </div>
  <section class="section-group">
    <div class="section-group__inner">
    </div>
  </section>
</div>
<?php get_footer(); ?>